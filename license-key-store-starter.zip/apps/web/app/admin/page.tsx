const stats = [
  ["ยอดขายวันนี้", "฿0", "ตัวอย่างข้อมูล"],
  ["รอตรวจสอบ", "0", "คำสั่งซื้อ"],
  ["License ใช้งานอยู่", "0", "คีย์"],
  ["ลูกค้าทั้งหมด", "0", "บัญชี"]
];

export default function AdminPage() {
  return (
    <main style={{ maxWidth: 1180, margin: "0 auto", padding: "28px 20px 64px" }}>
      <header style={{ display: "flex", justifyContent: "space-between", alignItems: "center", gap: 16, marginBottom: 36 }}>
        <div><a href="/" className="muted">license store / </a><strong>Admin</strong></div>
        <span className="muted" style={{ fontSize: 13 }}>UI preview · ต้องเพิ่มระบบยืนยันตัวตนแอดมิน</span>
      </header>
      <h1 style={{ fontSize: 36, letterSpacing: "-.04em", marginBottom: 6 }}>Dashboard</h1>
      <p className="muted" style={{ marginTop: 0, marginBottom: 28 }}>ภาพรวมระบบขาย License</p>
      <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit, minmax(210px, 1fr))", gap: 14 }}>
        {stats.map(([label, value, note]) => <article className="panel" key={label} style={{ padding: 22 }}>
          <p className="muted" style={{ marginTop: 0 }}>{label}</p><strong style={{ fontSize: 32 }}>{value}</strong>
          <p className="muted" style={{ fontSize: 13, marginBottom: 0 }}>{note}</p>
        </article>)}
      </div>
      <section className="panel" style={{ marginTop: 22, padding: 22 }}>
        <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", gap: 12 }}>
          <div><h2 style={{ margin: "0 0 6px", fontSize: 21 }}>คำสั่งซื้อที่รอตรวจสอบ</h2><p className="muted" style={{ margin: 0 }}>แอดมินตรวจสอบหลักฐานการชำระเงินก่อนอนุมัติ</p></div>
          <button className="btn-secondary" disabled>ดูคำสั่งซื้อ</button>
        </div>
        <p className="muted" style={{ marginTop: 22, fontSize: 14 }}>ยังไม่มีข้อมูลตัวอย่าง · เชื่อม API และสิทธิ์ ADMIN ก่อนใช้งาน</p>
      </section>
      <section className="panel" style={{ marginTop: 16, padding: 22 }}>
        <h2 style={{ marginTop: 0, fontSize: 21 }}>เมนูจัดการ</h2>
        <div style={{ display: "flex", flexWrap: "wrap", gap: 10 }}>
          {["คำสั่งซื้อ", "License Keys", "สมาชิก", "สินค้าและราคา", "ประวัติการทำงาน", "ตั้งค่าระบบ"].map(item => <span key={item} style={{ border: "1px solid #e5e5e5", borderRadius: 999, padding: "9px 14px", fontSize: 14 }}>{item}</span>)}
        </div>
      </section>
    </main>
  );
}
