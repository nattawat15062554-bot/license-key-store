const plans = [
  { name: "เริ่มต้น", duration: "1 วัน", price: "฿49" },
  { name: "มาตรฐาน", duration: "7 วัน", price: "฿199" },
  { name: "รายเดือน", duration: "30 วัน", price: "฿499" }
];

export default function HomePage() {
  return (
    <main style={{ maxWidth: 1100, margin: "0 auto", padding: "32px 20px 64px" }}>
      <header style={{ display: "flex", justifyContent: "space-between", alignItems: "center", gap: 16, marginBottom: 64 }}>
        <a href="/" style={{ fontWeight: 800, letterSpacing: "-.04em", fontSize: 22 }}>license<span style={{ color: "#737373" }}>store.</span></a>
        <nav style={{ display: "flex", gap: 18, alignItems: "center" }}>
          <a className="muted" href="/account">บัญชีของฉัน</a>
          <a className="btn" href="/account">เข้าสู่ระบบ</a>
        </nav>
      </header>
      <section style={{ maxWidth: 700, marginBottom: 48 }}>
        <p className="muted" style={{ textTransform: "uppercase", letterSpacing: ".16em", fontSize: 12 }}>LICENSE MANAGEMENT</p>
        <h1 style={{ fontSize: "clamp(38px, 7vw, 68px)", lineHeight: 1.04, letterSpacing: "-.06em", margin: "12px 0 18px" }}>
          License ที่จัดการง่าย<br />ในที่เดียว
        </h1>
        <p className="muted" style={{ fontSize: 18, lineHeight: 1.7, maxWidth: 600 }}>
          ซื้อสิทธิ์ใช้งาน ตรวจสอบสถานะคีย์ และจัดการอุปกรณ์ที่ผูกไว้ผ่านบัญชีของคุณ
        </p>
        <a className="btn" href="#plans" style={{ marginTop: 12 }}>ดูแพ็กเกจ</a>
      </section>
      <section id="plans">
        <div style={{ display: "flex", justifyContent: "space-between", alignItems: "end", gap: 16, marginBottom: 18 }}>
          <div><p className="muted" style={{ marginBottom: 6 }}>แพ็กเกจ</p><h2 style={{ fontSize: 28, margin: 0 }}>เลือก License ของคุณ</h2></div>
          <span className="muted" style={{ fontSize: 13 }}>ตัวอย่างราคา — แก้ไขได้</span>
        </div>
        <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit, minmax(220px, 1fr))", gap: 16 }}>
          {plans.map((p) => <article className="panel" key={p.name} style={{ padding: 24 }}>
            <p className="muted" style={{ marginTop: 0 }}>{p.name}</p>
            <h3 style={{ fontSize: 30, margin: "8px 0" }}>{p.price}</h3>
            <p className="muted">ระยะเวลา {p.duration}</p>
            <ul className="muted" style={{ paddingLeft: 20, lineHeight: 1.9 }}>
              <li>คีย์สำหรับซอฟต์แวร์ที่ได้รับอนุญาต</li>
              <li>ผูกอุปกรณ์ได้ 1 เครื่อง</li>
              <li>ตรวจสอบสถานะผ่านบัญชี</li>
            </ul>
            <a className="btn-secondary" href="/account" style={{ width: "100%", marginTop: 8 }}>เลือกแพ็กเกจ</a>
          </article>)}
        </div>
      </section>
      <footer className="muted" style={{ borderTop: "1px solid #e5e5e5", marginTop: 64, paddingTop: 20, fontSize: 13 }}>
        © {new Date().getFullYear()} License Store · License management for authorized software
      </footer>
    </main>
  );
}
