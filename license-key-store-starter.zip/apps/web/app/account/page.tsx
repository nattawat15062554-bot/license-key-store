export default function AccountPage() {
  return (
    <main style={{ maxWidth: 520, margin: "8vh auto", padding: 20 }}>
      <a href="/" className="muted">← กลับหน้าร้าน</a>
      <section className="panel" style={{ padding: 28, marginTop: 18 }}>
        <p className="muted" style={{ fontSize: 12, letterSpacing: ".14em" }}>CUSTOMER ACCOUNT</p>
        <h1 style={{ fontSize: 32, marginBottom: 8 }}>บัญชีของฉัน</h1>
        <p className="muted" style={{ lineHeight: 1.7 }}>หน้าตัวอย่างสำหรับเข้าสู่ระบบและดูคำสั่งซื้อ จะต้องเชื่อมกับระบบ Authentication ก่อนเปิดใช้งานจริง</p>
        <label style={{ display: "block", margin: "20px 0 6px" }}>อีเมล</label>
        <input disabled placeholder="you@example.com" style={{ width: "100%", padding: 12, border: "1px solid #ddd", borderRadius: 10 }} />
        <label style={{ display: "block", margin: "16px 0 6px" }}>รหัสผ่าน</label>
        <input disabled type="password" placeholder="••••••••" style={{ width: "100%", padding: 12, border: "1px solid #ddd", borderRadius: 10 }} />
        <button disabled className="btn" style={{ width: "100%", marginTop: 18, opacity: .5 }}>เข้าสู่ระบบ (ยังไม่เชื่อม Auth)</button>
      </section>
    </main>
  );
}
