import type { Metadata } from "next";
import "./globals.css";

export const metadata: Metadata = {
  title: "License Store",
  description: "License management for authorized software"
};

export default function RootLayout({ children }: Readonly<{ children: React.ReactNode }>) {
  return <html lang="th"><body>{children}</body></html>;
}
