import express from "express";
import cors from "cors";
import helmet from "helmet";
import { z } from "zod";
import { PrismaClient, LicenseStatus, OrderStatus } from "@prisma/client";
import { createHash, createHmac, randomBytes } from "node:crypto";

const app = express();
const prisma = new PrismaClient();
const port = Number(process.env.API_PORT ?? 4000);

app.use(helmet());
app.use(cors({ origin: process.env.WEB_ORIGIN ?? "http://localhost:3000" }));
app.use(express.json({ limit: "32kb" }));

app.get("/health", (_req, res) => res.json({ ok: true }));

// Demo-only placeholder. Replace with real session/JWT verification and role checks.
function requireAuth(_req: express.Request, res: express.Response, _next: express.NextFunction) {
  return res.status(501).json({ error: "Authentication middleware must be implemented before deployment." });
}
function requireAdmin(_req: express.Request, res: express.Response, _next: express.NextFunction) {
  return res.status(501).json({ error: "Admin authorization middleware must be implemented before deployment." });
}

const keyDigest = (key: string) =>
  createHash("sha256").update(key.trim()).digest("hex");

const deviceDigest = (installationId: string) => {
  const secret = process.env.DEVICE_HASH_SECRET;
  if (!secret) throw new Error("DEVICE_HASH_SECRET is required");
  return createHmac("sha256", secret).update(installationId).digest("hex");
};

// Customer submits an order for manual payment review.
app.post("/api/orders", requireAuth, async (req, res) => {
  const parsed = z.object({
    productId: z.string().min(1),
    paymentReference: z.string().max(120).optional(),
    paymentNote: z.string().max(500).optional()
  }).safeParse(req.body);
  if (!parsed.success) return res.status(400).json({ error: "Invalid request" });
  // TODO: obtain userId from verified auth context, never from the request body.
  return res.status(501).json({ error: "Connect verified session user and create order." });
});

// Admin reviews payment. Approval should atomically update order and issue a license.
app.post("/api/admin/orders/:id/review", requireAdmin, async (req, res) => {
  const parsed = z.object({
    decision: z.enum(["approve", "reject"]),
    note: z.string().max(500).optional()
  }).safeParse(req.body);
  if (!parsed.success) return res.status(400).json({ error: "Invalid request" });

  // TODO: use a DB transaction; ensure this order is still pending; issue one license only
  // on approval; record reviewer, review time, and an AuditEvent.
  return res.status(501).json({ error: "Implement transaction and license issuance." });
});

// Authorized client checks a license. Do not expose keyHash or deviceHash in responses.
app.post("/api/licenses/activate", async (req, res) => {
  const parsed = z.object({
    licenseKey: z.string().min(12).max(100),
    installationId: z.string().uuid()
  }).safeParse(req.body);
  if (!parsed.success) return res.status(400).json({ valid: false, error: "Invalid request" });

  const license = await prisma.license.findUnique({ where: { keyHash: keyDigest(parsed.data.licenseKey) } });
  if (!license) return res.status(404).json({ valid: false, error: "License not found" });
  if ([LicenseStatus.REVOKED, LicenseStatus.SUSPENDED].includes(license.status)) {
    return res.status(403).json({ valid: false, error: "License unavailable" });
  }

  const proposedDeviceHash = deviceDigest(parsed.data.installationId);
  if (license.deviceHash && license.deviceHash !== proposedDeviceHash) {
    return res.status(409).json({ valid: false, error: "License is bound to another installation" });
  }

  const now = new Date();
  const expiresAt = license.expiresAt ?? new Date(now.getTime() + license.durationDays * 86400000);
  if (expiresAt <= now) {
    await prisma.license.update({ where: { id: license.id }, data: { status: LicenseStatus.EXPIRED } });
    return res.status(403).json({ valid: false, error: "License expired" });
  }

  const updated = await prisma.license.update({
    where: { id: license.id },
    data: {
      deviceHash: proposedDeviceHash,
      activatedAt: license.activatedAt ?? now,
      expiresAt,
      status: LicenseStatus.ACTIVE
    }
  });

  return res.json({ valid: true, status: updated.status, expiresAt: updated.expiresAt });
});

// Admin overview. Enable only after requireAdmin is replaced with real middleware.
app.get("/api/admin/overview", requireAdmin, async (_req, res) => {
  const [users, ordersPending, activeLicenses, totalLicenses] = await Promise.all([
    prisma.user.count(),
    prisma.order.count({ where: { status: OrderStatus.PENDING_REVIEW } }),
    prisma.license.count({ where: { status: LicenseStatus.ACTIVE } }),
    prisma.license.count()
  ]);
  res.json({ users, ordersPending, activeLicenses, totalLicenses });
});

app.listen(port, () => console.log(`API listening on port ${port}`));

process.on("SIGINT", async () => {
  await prisma.$disconnect();
  process.exit(0);
});
