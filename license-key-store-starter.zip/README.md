# License Key Store

Starter scaffold for an authorized software license store with manual payment review,
device-bound licenses, and an admin dashboard.

## Stack
- Next.js App Router + TypeScript + Tailwind (web scaffold)
- Node.js + Express + TypeScript (API)
- PostgreSQL + Prisma
- Manual payment approval by an admin

## Important
This is a starter scaffold, not a production-audited system. Before launch:
- Configure HTTPS and secrets.
- Add rate limiting, email verification, password reset, CSRF protections where applicable,
  structured logging, backups, and monitoring.
- Add a real authentication provider/session implementation; the included auth routes are
  placeholders and must not be exposed as production authentication.
- Never put license-signing secrets in the browser.
- Do not use device identifiers that expose raw personal or hardware data; use an app-generated
  installation ID and store only a keyed hash.
- Integrate only with software you own or are authorized to license.

## Quick start
1. Install Node.js 20+ and Docker.
2. Copy `.env.example` to `.env` and replace all secrets.
3. Start PostgreSQL: `docker compose up -d db`
4. Install packages in `apps/api` and `apps/web`.
5. From `apps/api`, run `npx prisma generate` and `npx prisma migrate dev --name init`.
6. Start the API and web app in separate terminals.

This repository is intentionally a safe scaffold: the API includes license and order workflow
examples, while production authentication and payment evidence storage must be completed.
